from flask import Flask, render_template
from flask import request
from werkzeug.utils import redirect
from users_cr import connectToMySQL    # import the function that will return an instance of a connection
app = Flask(__name__)

@app.route("/")
def index():
    mysql = connectToMySQL('mydb')	        # call the function, passing in the name of our db
    users = mysql.query_db('SELECT * FROM users;')  # call the query_db function, pass in the query as a string
    print(users)
    return render_template("index.html", all_users = users)

@app.route("/create", methods = ["POST"])
def create_friend():
    return render_template("/create.html")

@app.route("/create_friend", methods=["POST"])
def add_friend_to_db():
    
    mysql = connectToMySQL('mydb')
    
    query = "INSERT INTO `mydb`.`users` (`first_name`, `last_name`, `email`) VALUES (%(fn)s, %(ln)s, %(mail)s);"
    data = {
            "fn": request.form["fname"],
            "ln": request.form["lname"],
            "mail": request.form["email"],
        }
    print(request.form)
    mysql.query_db(query,data)
    return redirect("/")
        
if __name__ == "__main__":
    app.run(debug=True)