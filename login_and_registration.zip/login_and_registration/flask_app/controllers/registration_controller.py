from flask import render_template, redirect, request, session, flash
from flask_app import app
from ..models.registration import Email
from flask_app.config.my_sequal_connections import connectToMySQL
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)

@app.route("/")
def index():
    if 'logged_in' not in session:
        session['logged_in'] = ""
    if session['logged_in'] != "":
        return render_template("dashboard.html")
    return render_template("index.html")


@app.route("/login", methods = ["POST", "GET"])
def login():
    if request.form['login'] == "" or request.form['pass'] == "":
        return redirect('/')
    Email.user_login(request.form)
    if((Email.user_login(request.form)) == False):
        return redirect("/")
    session['logged_in'] = request.form['login']
    return render_template("dashboard.html")


@app.route("/log_out")
def logout():
    session.clear()
    return redirect("/")


@app.route("/registration", methods = ["POST"])
def enter_email():
    print(request.form)
    if not Email.validate_email(request.form):
        return redirect('/')
    print(request.form)
    pw_hash = bcrypt.generate_password_hash(request.form['p_word'])
    cpw_hash = bcrypt.generate_password_hash(request.form['password_confirmation'])
    data = {
        "firstname": request.form['firstname'],
        "lastname":request.form['lastname'],
        "email_name": request.form['email_name'],
        "p_word" : pw_hash,
        "confirmpassword": cpw_hash
    }
    user_id = Email.add_email(data)
    session['user_id'] = user_id
    display = Email.display_emails()
    print(display)
    return render_template("info.html", all_emails = display)

    
if __name__ == "__main__":
    app.run(debug=True)