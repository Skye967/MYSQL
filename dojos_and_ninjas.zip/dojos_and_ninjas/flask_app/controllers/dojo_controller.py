from flask import render_template, redirect, request, session, flash
from flask_app import app
from ..models.dojo import Dojo
from ..models.ninja import Ninja
from flask_app.config.users_cr import connectToMySQL 


@app.route("/")
def index():
    dojo = Dojo.get_all_dojos()
    print(dojo)
    return render_template("index.html", all_dojos = dojo)


@app.route("/show/<int:dojo_id>")
def show_dojo_ninjas(dojo_id):
    print(dojo_id)
    this_dojo = Ninja.get_dojo_ninjas({"id": dojo_id})
    print(this_dojo)
    return render_template("show.html", all_ninjas = this_dojo)


@app.route("/create_dojo", methods = ["POST"])
def create_dojo():
    Dojo.add_dojo_to_db(request.form)
    print(request.form)
    return redirect("/")


@app.route("/create_ninja", methods = ["GET"])
def new_user():
    dojo = Dojo.get_all_dojos()
    return render_template("/create.html", all_dojos = dojo)


@app.route("/add_ninja", methods = ["POST"])
def create_user():
    Ninja.add_ninja_to_db(request.form)
    print(request.form)
    return redirect("/")


@app.route("/update/<int:user_id>", methods=["POST"])
def update_user_to_db(user_id):
    data = {
            "fn": request.form["fname"],
            "ln": request.form["lname"],
            "mail": request.form["email"],
            "id": user_id
        }
    User.update(data)
    print(request.form)
    return redirect("/")


@app.route("/show/<int:user_id>", methods = ["get"])
def show_user_form(user_id):
    this_user = User.get_user({"id": user_id})
    return render_template("show.html", user = this_user)


@app.route("/delete/<int:one_user_id>", methods = ["get"])
def delet_user(one_user_id):
    User.remove_user({"id": one_user_id})
    return redirect("/")
        
        
if __name__ == "__main__":
    app.run(debug=True)