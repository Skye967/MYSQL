from flask_app import app
from flask_app.config.users_cr import connectToMySQL


class Dojo:
    def __init__(self, data):
        self.id = data['id']
        self.name = data['name']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.ninjas = []
           
         
    @classmethod
    def get_all_dojos(cls):
        query = "SELECT * FROM dojos;"
        dojos_from_db = connectToMySQL("mydb").query_db(query)
        dojos = [] 
        for dojo in dojos_from_db:
            dojos.append(cls(dojo)) 
        return dojos
    
    
    @classmethod
    def add_dojo_to_db(cls, data):
        query = "INSERT INTO `mydb`.`dojos` (name, created_at, updated_at) VALUES (%(name)s,  NOW(), NOW());"
        #query = "INSERT INTO mydb.dojos (first_name, last_name, email, created_at, updated_at) VALUES (%(fname)s, %(lname)s, %(email)s, NOW(), NOW());"
        user_id = connectToMySQL('mydb').query_db(query,data)
        print(query)
        return user_id


    @classmethod
    def get_one_user(cls, add_user):
        query = "SELECT * FROM users WHERE id = %(id)s;"
        results = connectToMySQL("mydb").query_db(query, data)
        user_obj = cls(results[0])
        return user_obj
        
    @classmethod
    def update(cls, data):
        query = "UPDATE `mydb`.`users` SET `first_name` = %(fn)s, `last_name` = %(ln)s, `email` = %(mail)s WHERE (`id` = %(id)s);"
        user_id = connectToMySQL("mydb").query_db(query, data)
        return user_id
        
        
    @classmethod
    def get_user(cls, user_id):
        query = "SELECT * FROM users WHERE id = %(id)s;"
        results = connectToMySQL("mydb").query_db(query, user_id)
        user = cls(results[0])
        for row in results:
            data = {
            "id": user_id
            }
        return user
        
        
    @classmethod
    def remove_user(cls,one_user_id):
        query = "DELETE FROM `mydb`.`users` WHERE (`id` = %(id)s);"
        connectToMySQL("mydb").query_db(query, one_user_id)
    
