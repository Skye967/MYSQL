class User:
    def __init__(self, data):
        self.id = data['id']
        self.fname = data['first_name']
        self.lname = data['last_name']
        self.mail = data['email']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        users = []
        
print(User)