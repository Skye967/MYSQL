from flask_app import app
from flask_app.config.users_cr import connectToMySQL


class User:
    def __init__(self, data):
        self.id = data['id']
        self.fname = data['first_name']
        self.lname = data['last_name']
        self.mail = data['email']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        users = []
           
         
    @classmethod
    def get_all_users(cls):
        query = "SELECT * FROM users;"
        users_from_db = connectToMySQL("mydb").query_db(query)
        users = [] 
        for user in users_from_db:
            users.append(cls(user)) 
        return users
    

    @classmethod
    def add_user_to_db(cls, data):
        query = "INSERT INTO mydb.users (first_name, last_name, email, created_at, updated_at) VALUES (%(fname)s, %(lname)s, %(email)s, NOW(), NOW());"
        user_id = connectToMySQL('mydb').query_db(query,data)
        print(query)
        return user_id


    @classmethod
    def get_one_user(cls, add_user):
        query = "SELECT * FROM users WHERE id = %(id)s;"
        results = connectToMySQL("mydb").query_db(query, data)
        user_obj = cls(results[0])
        return user_obj
        
    @classmethod
    def update(cls, data):
        query = "UPDATE `mydb`.`users` SET `first_name` = %(fn)s, `last_name` = %(ln)s, `email` = %(mail)s WHERE (`id` = %(id)s);"
        user_id = connectToMySQL("mydb").query_db(query, data)
        return user_id
        
        
    @classmethod
    def get_user(cls, user_id):
        query = "SELECT * FROM users WHERE id = %(id)s;"
        results = connectToMySQL("mydb").query_db(query, user_id)
        user = cls(results[0])
        for row in results:
            data = {
            "id": user_id
            }
        return user
        
        
    @classmethod
    def remove_user(cls,one_user_id):
        query = "DELETE FROM `mydb`.`users` WHERE (`id` = %(id)s);"
        connectToMySQL("mydb").query_db(query, one_user_id)
    
