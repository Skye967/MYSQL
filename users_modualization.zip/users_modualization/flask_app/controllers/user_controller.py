from flask import render_template, redirect, request, session, flash
from flask_app import app
from ..models.user import User
from flask_app.config.users_cr import connectToMySQL 


@app.route("/")
def index():
    use = User.get_all_users()
    return render_template("index.html", all_users = use)


@app.route("/create", methods = ["POST"])
def new_user():
    return render_template("/create.html")


@app.route("/create_user", methods = ["POST"])
def create_user():
    User.add_user_to_db(request.form)
    print(request.form)
    return redirect("/")


@app.route("/edit/<int:user_id>", methods = ["get"])
def edit_user_form(user_id):
    this_user = User.get_user({"id": user_id})
    return render_template("edit.html", user = this_user)


@app.route("/update/<int:user_id>", methods=["POST"])
def update_user_to_db(user_id):
    data = {
            "fn": request.form["fname"],
            "ln": request.form["lname"],
            "mail": request.form["email"],
            "id": user_id
        }
    User.update(data)
    print(request.form)
    return redirect("/")


@app.route("/show/<int:user_id>", methods = ["get"])
def show_user_form(user_id):
    this_user = User.get_user({"id": user_id})
    return render_template("show.html", user = this_user)


@app.route("/delete/<int:one_user_id>", methods = ["get"])
def delet_user(one_user_id):
    User.remove_user({"id": one_user_id})
    return redirect("/")
        
        
if __name__ == "__main__":
    app.run(debug=True)