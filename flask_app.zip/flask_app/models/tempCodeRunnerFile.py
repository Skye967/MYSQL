@classmethod
def get_all_dogs(cls):
    query = "SELECT * FROM dogs;"
    dogs_from_db = connectToMySQL("dogs_schema").query_db(query)
    dogs = [] 
    for dog in dogs_from_db:
        dogs.append(cls(dog)) 
    print(somthing)
    return dogs
    print(Dog.get_all_dogs())