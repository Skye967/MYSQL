from flask import Flask, render_template
from flask import request
from werkzeug.utils import redirect
from users_cr import connectToMySQL   
 
app = Flask(__name__)


@app.route("/")
def index():
    mysql = connectToMySQL('mydb')	        
    users = mysql.query_db('SELECT * FROM users;')  
    print(users)
    return render_template("index.html", all_users = users)


@app.route("/create", methods = ["POST"])
def create_friend():
    return render_template("/create.html")


@app.route("/create_friend", methods=["POST"])
def add_friend_to_db():
    mysql = connectToMySQL('mydb')
    query = "INSERT INTO `mydb`.`users` (`first_name`, `last_name`, `email`) VALUES (%(fn)s, %(ln)s, %(mail)s);"
    data = {
            "fn": request.form["fname"],
            "ln": request.form["lname"],
            "mail": request.form["email"],
        }
    print(request.form)
    mysql.query_db(query,data)
    return redirect("/")


@app.route("/edit/<int:one_user_id>", methods = ["get"])
def edit_dog_form(one_user_id):
    mysql = connectToMySQL("mydb")
    query = "SELECT * FROM users WHERE id = %(id)s;"
    data = {
        "id": one_user_id
    }
    user_list = mysql.query_db(query, data)
    return render_template("edit.html", user = user_list[0])


@app.route("/update/<int:user_id>", methods=["POST"])
def update_user_to_db(user_id):
    mysql = connectToMySQL('mydb')
    query = "UPDATE `mydb`.`users` SET `first_name` = %(fn)s, `last_name` = %(ln)s, `email` = %(mail)s WHERE (`id` = %(id)s);"
    data = {
            "fn": request.form["fname"],
            "ln": request.form["lname"],
            "mail": request.form["email"],
            "id": user_id
        }
    print(request.form)
    mysql.query_db(query,data)
    return redirect("/")


@app.route("/show/<int:one_user_id>", methods = ["get"])
def show_user_form(one_user_id):
    mysql = connectToMySQL("mydb")
    query = "SELECT * FROM users WHERE id = %(id)s;"
    data = {
        "id": one_user_id
    }
    user_list = mysql.query_db(query, data)
    return render_template("show.html", user = user_list[0])


@app.route("/delete/<int:one_user_id>", methods = ["get"])
def delet_user(one_user_id):
    mysql = connectToMySQL("mydb")
    query = "DELETE FROM `mydb`.`users` WHERE (`id` = %(id)s);"
    data = {
        "id": one_user_id
    }
    user_list = mysql.query_db(query, data)
    return redirect("/")
        
        
if __name__ == "__main__":
    app.run(debug=True)