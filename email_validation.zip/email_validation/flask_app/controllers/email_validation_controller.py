from flask import render_template, redirect, request, session, flash
from flask_app import app
from ..models.email import Email
from flask_app.config.my_sequal_connections import connectToMySQL 

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/add_email", methods = ["POST"])
def enter_email():
    if not Email.validate_email(request.form):
        return redirect('/')
    Email.add_email(request.form)
    display = Email.display_emails()
    return render_template("info.html", all_emails = display)
    

if __name__ == "__main__":
    app.run(debug=True)