from flask_app import app
from flask import flash
import re
from flask_app.config.my_sequal_connections import connectToMySQL

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
class Email:
    def __init__(self, data):
        self.id = data['id']
        self.name = data['email_name']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.emails = []
        
        
    @classmethod
    def display_emails(cls):
        query = "SELECT * FROM email.emails;"
        emails_from_db = connectToMySQL("email").query_db(query)
        emails = [] 
        for email in emails_from_db:
            emails.append(cls(email)) 
        return emails
    
    
    @classmethod
    def add_email(cls,data):
        query = "INSERT INTO email.emails (email_name, updated_at) VALUES (%(email_name)s, NOW());"
        user_id = connectToMySQL('email').query_db(query,data)
        print(query)
        return user_id
    
     
    @staticmethod
    def validate_email( user ):
        is_valid = True
        ename = (user['email_name'])
        if not EMAIL_REGEX.match(user['email_name']): 
            flash("Invalid email address!")
            is_valid = False
        if  EMAIL_REGEX.match(user['email_name']): 
            flash(f"The email that you have entered {ename} is a valid email adress!")
            is_valid = True 
        return is_valid