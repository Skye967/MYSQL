from flask import render_template, redirect, request, session, flash
from flask_app import app
from ..models.locations import Location
from ..models.language import Language
from ..models.user import User
from flask_app.config.my_sequal_connections import connectToMySQL 


@app.route("/")
def index():
    language = Language.get_all_languages()
    location = Location.get_all_locations()
    return render_template("index.html", all_locations = location, all_languages = language)


@app.route("/add_user", methods = ['POST','GET'])
def display_user():
    print(request.form)
    if not User.validate_user(request.form):
        return redirect('/')
    User.add_user(request.form)
    display = User.display_user()
    return render_template("info.html", display_user = display )





if __name__ == "__main__":
    app.run(debug=True)