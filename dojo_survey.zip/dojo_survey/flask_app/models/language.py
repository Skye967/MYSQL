from flask_app import app
from flask_app.config.my_sequal_connections import connectToMySQL


class Language:
    def __init__(self, data):
        self.id = data['id']
        self.name = data['language_names']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.languages = []
        
        
    @classmethod
    def get_all_languages(cls):
        query = "SELECT * FROM dojo_survey.languages;"
        languages_from_db = connectToMySQL("dojo_survey").query_db(query)
        languages = [] 
        for language in languages_from_db:
            languages.append(cls(language)) 
        return languages