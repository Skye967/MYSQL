from flask_app import app
from flask_app.config.my_sequal_connections import connectToMySQL


class Location:
    def __init__(self, data):
        self.id = data['id']
        self.name = data['location_names']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.locations = []
        

    @classmethod
    def get_all_locations(cls):
        query = "SELECT * FROM dojo_survey.locations;"
        locations_from_db = connectToMySQL("dojo_survey").query_db(query)
        locations = [] 
        for location in locations_from_db:
            locations.append(cls(location)) 
        return locations