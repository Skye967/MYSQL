from flask_app import app
from flask import flash
from flask_app.config.my_sequal_connections import connectToMySQL


class User:
    def __init__(self, data):
        self.id = data['id']
        self.name = data['user_names']
        self.language_id = data['language_id']
        self.location_id = data['location_id']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.users = []
        
        
    @classmethod
    def get_all_users(cls):
        query = "SELECT * FROM dojo_survey.languages;"
        users_from_db = connectToMySQL("dojo_survey").query_db(query)
        users = [] 
        for user in users_from_db:
            users.append(cls(user)) 
        return users
    
    
    @classmethod
    def add_user(cls,data):
        query = "INSERT INTO users (location_id, language_id, user_names, comment) VALUES (%(location)s,%(language)s,%(fullname)s, %(comment)s);"
        user_id = connectToMySQL('dojo_survey').query_db(query,data)
        return user_id
    
    
    @classmethod
    def display_user(cls):
        query = "SELECT user_names, language_names, location_names FROM users JOIN languages ON languages.id = users.language_id JOIN locations ON locations.id = users.location_id ORDER BY users.id DESC LIMIT 1"
        user_id = connectToMySQL('dojo_survey').query_db(query)
        return user_id
    
    
    @staticmethod
    def validate_user(user):
        is_valid = True 
        if len(user['fullname']) < 3:
            flash("Name must be at least 3 characters.")
            is_valid = False
        return is_valid
            